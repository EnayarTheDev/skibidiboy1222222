import { useParams } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Input } from "@/components/ui/input";
import { Search, ArrowUp, ArrowDown } from "lucide-react";
import { useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Item {
  id: string;
  name: string;
  value: number;
  demand: "High" | "Medium" | "Low";
  rarity: string;
  trend: number;
}

const gameData: Record<string, { name: string; items: Item[] }> = {
  mm2: {
    name: "Murder Mystery 2",
    items: [
      { id: "1", name: "Chroma Luger", value: 210, demand: "High", rarity: "Chroma", trend: 16.67 },
      { id: "2", name: "Chroma Fang", value: 245, demand: "High", rarity: "Chroma", trend: 11.36 },
      { id: "3", name: "Icebreaker", value: 85, demand: "Medium", rarity: "Godly", trend: -5 },
      { id: "4", name: "Luger", value: 45, demand: "Medium", rarity: "Godly", trend: 2 },
      { id: "5", name: "Eternal Cane", value: 180, demand: "High", rarity: "Godly", trend: 8 },
    ],
  },
  bladeball: {
    name: "Blade Ball",
    items: [
      { id: "1", name: "Inferno Blade", value: 520, demand: "High", rarity: "Legendary", trend: 15.56 },
      { id: "2", name: "Plasma Saber", value: 380, demand: "Medium", rarity: "Legendary", trend: -5 },
      { id: "3", name: "Shadow Katana", value: 290, demand: "Medium", rarity: "Epic", trend: 3 },
      { id: "4", name: "Golden Blade", value: 450, demand: "High", rarity: "Legendary", trend: 12 },
    ],
  },
  bloxfruits: {
    name: "Blox Fruits",
    items: [
      { id: "1", name: "Dragon Fruit", value: 2200, demand: "High", rarity: "Mythical", trend: -12 },
      { id: "2", name: "Leopard Fruit", value: 2800, demand: "High", rarity: "Mythical", trend: 7.69 },
      { id: "3", name: "Buddha Fruit", value: 1200, demand: "High", rarity: "Legendary", trend: 5 },
      { id: "4", name: "Dough Fruit", value: 2400, demand: "High", rarity: "Mythical", trend: -3 },
    ],
  },
  growagarden: {
    name: "Grow a Garden",
    items: [
      { id: "1", name: "Godly Seed", value: 125, demand: "High", rarity: "Godly", trend: -16.67 },
      { id: "2", name: "Rainbow Flower", value: 340, demand: "Medium", rarity: "Rare", trend: 13.33 },
      { id: "3", name: "Golden Watering Can", value: 200, demand: "Medium", rarity: "Epic", trend: 0 },
    ],
  },
  petsim99: {
    name: "Pet Simulator 99",
    items: [
      { id: "1", name: "Huge Cat", value: 9200, demand: "High", rarity: "Huge", trend: 8.24 },
      { id: "2", name: "Titanic Dog", value: 11500, demand: "High", rarity: "Titanic", trend: -4.17 },
      { id: "3", name: "Huge Pegasus", value: 15000, demand: "High", rarity: "Huge", trend: 10 },
    ],
  },
  adoptme: {
    name: "Adopt Me",
    items: [
      { id: "1", name: "Shadow Dragon", value: 5000, demand: "High", rarity: "Legendary", trend: 5 },
      { id: "2", name: "Frost Dragon", value: 3500, demand: "High", rarity: "Legendary", trend: -2 },
      { id: "3", name: "Bat Dragon", value: 4200, demand: "High", rarity: "Legendary", trend: 8 },
    ],
  },
};

const Game = () => {
  const { slug } = useParams<{ slug: string }>();
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState("value");

  const game = gameData[slug || ""] || { name: "Unknown Game", items: [] };

  let filteredItems = game.items.filter(item =>
    item.name.toLowerCase().includes(search.toLowerCase())
  );

  if (sortBy === "value") {
    filteredItems = filteredItems.sort((a, b) => b.value - a.value);
  } else if (sortBy === "demand") {
    const demandOrder = { High: 0, Medium: 1, Low: 2 };
    filteredItems = filteredItems.sort((a, b) => demandOrder[a.demand] - demandOrder[b.demand]);
  } else if (sortBy === "trend") {
    filteredItems = filteredItems.sort((a, b) => b.trend - a.trend);
  }

  const getDemandColor = (demand: string) => {
    switch (demand) {
      case "High": return "text-accent";
      case "Medium": return "text-primary";
      case "Low": return "text-muted-foreground";
      default: return "text-foreground";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="font-display text-4xl font-bold text-foreground mb-2">{game.name}</h1>
          <p className="text-muted-foreground">{game.items.length} items tracked</p>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search items..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 bg-card border-border"
            />
          </div>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-48 bg-card border-border">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="value">Highest Value</SelectItem>
              <SelectItem value="demand">Demand</SelectItem>
              <SelectItem value="trend">Trending</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Items Grid */}
        <div className="grid gap-4">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="flex items-center justify-between p-4 rounded-lg bg-card border border-border hover:border-primary/30 transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <span className="text-lg">🎮</span>
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">{item.name}</h3>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-secondary text-xs text-muted-foreground">{item.rarity}</span>
                    <span className={`text-sm ${getDemandColor(item.demand)}`}>{item.demand} Demand</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div className="text-right">
                  <p className="font-display text-xl font-bold text-primary">{item.value.toLocaleString()}</p>
                  <div className={`flex items-center justify-end gap-1 text-sm ${item.trend >= 0 ? 'text-accent' : 'text-destructive'}`}>
                    {item.trend >= 0 ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}
                    <span>{Math.abs(item.trend)}%</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredItems.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No items found</p>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
};

export default Game;
