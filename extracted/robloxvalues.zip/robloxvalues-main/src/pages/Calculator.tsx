import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { ArrowRightLeft, Plus, Trash2, Check, X } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Item {
  id: string;
  name: string;
  value: number;
  game: string;
}

const sampleItems: Item[] = [
  { id: "1", name: "Chroma Luger", value: 210, game: "mm2" },
  { id: "2", name: "Chroma Fang", value: 245, game: "mm2" },
  { id: "3", name: "Icebreaker", value: 85, game: "mm2" },
  { id: "4", name: "Dragon Fruit", value: 2200, game: "bloxfruits" },
  { id: "5", name: "Leopard Fruit", value: 2800, game: "bloxfruits" },
  { id: "6", name: "Inferno Blade", value: 520, game: "bladeball" },
  { id: "7", name: "Plasma Saber", value: 380, game: "bladeball" },
  { id: "8", name: "Godly Seed", value: 125, game: "growagarden" },
  { id: "9", name: "Rainbow Flower", value: 340, game: "growagarden" },
];

const Calculator = () => {
  const [yourItems, setYourItems] = useState<Item[]>([]);
  const [theirItems, setTheirItems] = useState<Item[]>([]);
  const [selectedGame, setSelectedGame] = useState<string>("all");

  const filteredItems = selectedGame === "all" 
    ? sampleItems 
    : sampleItems.filter(item => item.game === selectedGame);

  const addToYours = (item: Item) => {
    setYourItems([...yourItems, { ...item, id: `${item.id}-${Date.now()}` }]);
  };

  const addToTheirs = (item: Item) => {
    setTheirItems([...theirItems, { ...item, id: `${item.id}-${Date.now()}` }]);
  };

  const removeFromYours = (id: string) => {
    setYourItems(yourItems.filter(item => item.id !== id));
  };

  const removeFromTheirs = (id: string) => {
    setTheirItems(theirItems.filter(item => item.id !== id));
  };

  const yourTotal = yourItems.reduce((sum, item) => sum + item.value, 0);
  const theirTotal = theirItems.reduce((sum, item) => sum + item.value, 0);
  const difference = yourTotal - theirTotal;
  const isFair = Math.abs(difference) <= Math.max(yourTotal, theirTotal) * 0.1;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="font-display text-4xl font-bold text-foreground mb-2">Trade Calculator</h1>
          <p className="text-muted-foreground">Compare item values to ensure fair trades</p>
        </div>

        {/* Game Filter */}
        <div className="mb-6">
          <Select value={selectedGame} onValueChange={setSelectedGame}>
            <SelectTrigger className="w-48 bg-card border-border">
              <SelectValue placeholder="Select game" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Games</SelectItem>
              <SelectItem value="mm2">Murder Mystery 2</SelectItem>
              <SelectItem value="bladeball">Blade Ball</SelectItem>
              <SelectItem value="bloxfruits">Blox Fruits</SelectItem>
              <SelectItem value="growagarden">Grow a Garden</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Item Selection */}
        <div className="mb-8 p-4 rounded-lg bg-card border border-border">
          <h3 className="font-semibold text-foreground mb-4">Available Items</h3>
          <div className="flex flex-wrap gap-2">
            {filteredItems.map((item) => (
              <div key={item.id} className="flex items-center gap-2 p-2 rounded-lg bg-secondary border border-border">
                <span className="text-sm font-medium text-foreground">{item.name}</span>
                <span className="text-xs text-muted-foreground">({item.value})</span>
                <Button size="sm" variant="ghost" onClick={() => addToYours(item)} className="h-6 w-6 p-0">
                  <Plus className="h-3 w-3 text-accent" />
                </Button>
                <Button size="sm" variant="ghost" onClick={() => addToTheirs(item)} className="h-6 w-6 p-0">
                  <Plus className="h-3 w-3 text-primary" />
                </Button>
              </div>
            ))}
          </div>
        </div>

        {/* Trade Comparison */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Your Items */}
          <div className="p-6 rounded-lg bg-card border-2 border-accent/50">
            <h3 className="font-display text-xl font-bold text-accent mb-4">Your Items</h3>
            <div className="space-y-2 min-h-[200px]">
              {yourItems.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">Add items to your side</p>
              ) : (
                yourItems.map((item) => (
                  <div key={item.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary">
                    <span className="text-foreground">{item.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">{item.value}</span>
                      <Button size="sm" variant="ghost" onClick={() => removeFromYours(item.id)} className="h-6 w-6 p-0">
                        <Trash2 className="h-3 w-3 text-destructive" />
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
            <div className="mt-4 pt-4 border-t border-border">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Total Value:</span>
                <span className="font-display text-2xl font-bold text-accent">{yourTotal.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Their Items */}
          <div className="p-6 rounded-lg bg-card border-2 border-primary/50">
            <h3 className="font-display text-xl font-bold text-primary mb-4">Their Items</h3>
            <div className="space-y-2 min-h-[200px]">
              {theirItems.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">Add items to their side</p>
              ) : (
                theirItems.map((item) => (
                  <div key={item.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary">
                    <span className="text-foreground">{item.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">{item.value}</span>
                      <Button size="sm" variant="ghost" onClick={() => removeFromTheirs(item.id)} className="h-6 w-6 p-0">
                        <Trash2 className="h-3 w-3 text-destructive" />
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
            <div className="mt-4 pt-4 border-t border-border">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Total Value:</span>
                <span className="font-display text-2xl font-bold text-primary">{theirTotal.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Result */}
        {(yourItems.length > 0 || theirItems.length > 0) && (
          <div className={`p-6 rounded-lg border-2 ${isFair ? 'bg-accent/10 border-accent' : 'bg-destructive/10 border-destructive'}`}>
            <div className="flex items-center justify-center gap-4">
              <ArrowRightLeft className={`h-8 w-8 ${isFair ? 'text-accent' : 'text-destructive'}`} />
              <div className="text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  {isFair ? (
                    <Check className="h-6 w-6 text-accent" />
                  ) : (
                    <X className="h-6 w-6 text-destructive" />
                  )}
                  <span className={`font-display text-2xl font-bold ${isFair ? 'text-accent' : 'text-destructive'}`}>
                    {isFair ? 'Fair Trade!' : 'Unfair Trade'}
                  </span>
                </div>
                <p className="text-muted-foreground">
                  Difference: <span className={difference >= 0 ? 'text-accent' : 'text-destructive'}>
                    {difference >= 0 ? '+' : ''}{difference.toLocaleString()}
                  </span>
                  {' '}({difference >= 0 ? 'You gain' : 'You lose'})
                </p>
              </div>
            </div>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
};

export default Calculator;
