import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { ArrowDown, ArrowUp, Clock, Search, TrendingUp, TrendingDown } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface ValueChange {
  id: string;
  itemName: string;
  game: string;
  oldValue: number;
  newValue: number;
  change: number;
  timestamp: string;
  rarity: string;
}

const allChanges: ValueChange[] = [
  { id: "1", itemName: "Chroma Luger", game: "MM2", oldValue: 180, newValue: 210, change: 16.67, timestamp: "2h ago", rarity: "Chroma" },
  { id: "2", itemName: "Dragon Fruit", game: "Blox Fruits", oldValue: 2500, newValue: 2200, change: -12, timestamp: "3h ago", rarity: "Mythical" },
  { id: "3", itemName: "Inferno Blade", game: "Blade Ball", oldValue: 450, newValue: 520, change: 15.56, timestamp: "5h ago", rarity: "Legendary" },
  { id: "4", itemName: "Huge Cat", game: "Pet Sim 99", oldValue: 8500, newValue: 9200, change: 8.24, timestamp: "6h ago", rarity: "Huge" },
  { id: "5", itemName: "Godly Seed", game: "Grow a Garden", oldValue: 150, newValue: 125, change: -16.67, timestamp: "8h ago", rarity: "Godly" },
  { id: "6", itemName: "Chroma Fang", game: "MM2", oldValue: 220, newValue: 245, change: 11.36, timestamp: "10h ago", rarity: "Chroma" },
  { id: "7", itemName: "Leopard Fruit", game: "Blox Fruits", oldValue: 2600, newValue: 2800, change: 7.69, timestamp: "12h ago", rarity: "Mythical" },
  { id: "8", itemName: "Plasma Saber", game: "Blade Ball", oldValue: 400, newValue: 380, change: -5, timestamp: "14h ago", rarity: "Legendary" },
  { id: "9", itemName: "Rainbow Flower", game: "Grow a Garden", oldValue: 300, newValue: 340, change: 13.33, timestamp: "16h ago", rarity: "Rare" },
  { id: "10", itemName: "Titanic Dog", game: "Pet Sim 99", oldValue: 12000, newValue: 11500, change: -4.17, timestamp: "1 day ago", rarity: "Titanic" },
];

const Values = () => {
  const [search, setSearch] = useState("");
  const [selectedGame, setSelectedGame] = useState("all");
  const [sortBy, setSortBy] = useState("recent");

  let filteredChanges = allChanges.filter(change => {
    const matchesSearch = change.itemName.toLowerCase().includes(search.toLowerCase());
    const matchesGame = selectedGame === "all" || change.game.toLowerCase().includes(selectedGame);
    return matchesSearch && matchesGame;
  });

  if (sortBy === "gainers") {
    filteredChanges = filteredChanges.filter(c => c.change > 0).sort((a, b) => b.change - a.change);
  } else if (sortBy === "losers") {
    filteredChanges = filteredChanges.filter(c => c.change < 0).sort((a, b) => a.change - b.change);
  }

  const gainers = allChanges.filter(c => c.change > 0).length;
  const losers = allChanges.filter(c => c.change < 0).length;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="font-display text-4xl font-bold text-foreground mb-2">Value Changes</h1>
          <p className="text-muted-foreground">Track item value fluctuations across all games</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="p-4 rounded-lg bg-card border border-border">
            <div className="flex items-center gap-2 text-accent mb-1">
              <TrendingUp className="h-5 w-5" />
              <span className="text-sm">Gainers</span>
            </div>
            <span className="font-display text-2xl font-bold text-foreground">{gainers}</span>
          </div>
          <div className="p-4 rounded-lg bg-card border border-border">
            <div className="flex items-center gap-2 text-destructive mb-1">
              <TrendingDown className="h-5 w-5" />
              <span className="text-sm">Losers</span>
            </div>
            <span className="font-display text-2xl font-bold text-foreground">{losers}</span>
          </div>
          <div className="p-4 rounded-lg bg-card border border-border">
            <div className="flex items-center gap-2 text-primary mb-1">
              <Clock className="h-5 w-5" />
              <span className="text-sm">Last Update</span>
            </div>
            <span className="font-display text-lg font-bold text-foreground">2h ago</span>
          </div>
          <div className="p-4 rounded-lg bg-card border border-border">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <span className="text-sm">Total Changes</span>
            </div>
            <span className="font-display text-2xl font-bold text-foreground">{allChanges.length}</span>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search items..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 bg-card border-border"
            />
          </div>
          <Select value={selectedGame} onValueChange={setSelectedGame}>
            <SelectTrigger className="w-48 bg-card border-border">
              <SelectValue placeholder="Filter by game" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Games</SelectItem>
              <SelectItem value="mm2">Murder Mystery 2</SelectItem>
              <SelectItem value="blade">Blade Ball</SelectItem>
              <SelectItem value="blox">Blox Fruits</SelectItem>
              <SelectItem value="garden">Grow a Garden</SelectItem>
              <SelectItem value="pet">Pet Simulator 99</SelectItem>
            </SelectContent>
          </Select>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-48 bg-card border-border">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="recent">Most Recent</SelectItem>
              <SelectItem value="gainers">Top Gainers</SelectItem>
              <SelectItem value="losers">Top Losers</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Changes List */}
        <div className="space-y-3">
          {filteredChanges.map((change) => (
            <div
              key={change.id}
              className="flex items-center justify-between p-4 rounded-lg bg-card border border-border hover:border-primary/30 transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className={`p-2 rounded-lg ${change.change >= 0 ? 'bg-accent/20' : 'bg-destructive/20'}`}>
                  {change.change >= 0 ? (
                    <ArrowUp className="h-5 w-5 text-accent" />
                  ) : (
                    <ArrowDown className="h-5 w-5 text-destructive" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-foreground">{change.itemName}</h3>
                    <span className="px-2 py-0.5 rounded bg-primary/20 text-xs text-primary">{change.rarity}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{change.game}</p>
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">
                    {change.oldValue.toLocaleString()} → {change.newValue.toLocaleString()}
                  </p>
                  <p className={`font-semibold ${change.change >= 0 ? 'text-accent' : 'text-destructive'}`}>
                    {change.change >= 0 ? '+' : ''}{change.change.toFixed(2)}%
                  </p>
                </div>
                <div className="flex items-center gap-1 text-muted-foreground min-w-[80px]">
                  <Clock className="h-4 w-4" />
                  <span className="text-sm">{change.timestamp}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Values;
