import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, ShoppingCart, Star, Zap, Shield, Clock } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";

interface ShopItem {
  id: string;
  name: string;
  game: string;
  description: string;
  price: number;
  originalPrice?: number;
  stock: number;
  category: string;
  rarity: string;
  imageUrl?: string;
  isFeatured: boolean;
}

const sampleItems: ShopItem[] = [
  { id: "1", name: "Chroma Luger", game: "MM2", description: "Legendary chroma weapon", price: 15.99, originalPrice: 19.99, stock: 50, category: "Weapon", rarity: "Chroma", imageUrl: "", isFeatured: true },
  { id: "2", name: "Chroma Fang", game: "MM2", description: "Rare chroma knife", price: 22.99, originalPrice: 29.99, stock: 30, category: "Weapon", rarity: "Chroma", imageUrl: "", isFeatured: true },
  { id: "3", name: "Icebreaker", game: "MM2", description: "Godly weapon", price: 8.99, originalPrice: 12.99, stock: 100, category: "Weapon", rarity: "Godly", imageUrl: "", isFeatured: false },
  { id: "4", name: "Dragon Fruit", game: "Blox Fruits", description: "Mythical fruit with dragon powers", price: 25.00, originalPrice: 35.00, stock: 20, category: "Fruit", rarity: "Mythical", imageUrl: "", isFeatured: true },
  { id: "5", name: "Leopard Fruit", game: "Blox Fruits", description: "Top tier mythical fruit", price: 32.99, originalPrice: 45.00, stock: 15, category: "Fruit", rarity: "Mythical", imageUrl: "", isFeatured: true },
  { id: "6", name: "Buddha Fruit", game: "Blox Fruits", description: "Legendary transformation fruit", price: 18.50, originalPrice: 25.00, stock: 40, category: "Fruit", rarity: "Legendary", imageUrl: "", isFeatured: false },
  { id: "7", name: "Inferno Blade", game: "Blade Ball", description: "Legendary fire blade", price: 12.99, originalPrice: 18.99, stock: 75, category: "Blade", rarity: "Legendary", imageUrl: "", isFeatured: true },
  { id: "8", name: "Plasma Saber", game: "Blade Ball", description: "Epic energy weapon", price: 9.99, originalPrice: 14.99, stock: 60, category: "Blade", rarity: "Epic", imageUrl: "", isFeatured: false },
  { id: "9", name: "Godly Seed", game: "Grow a Garden", description: "Rare godly plant seed", price: 4.99, originalPrice: 7.99, stock: 200, category: "Seed", rarity: "Godly", imageUrl: "", isFeatured: false },
  { id: "10", name: "Rainbow Flower", game: "Grow a Garden", description: "Beautiful rainbow flower", price: 11.99, originalPrice: 16.99, stock: 80, category: "Plant", rarity: "Rare", imageUrl: "", isFeatured: true },
  { id: "11", name: "Huge Cat", game: "Pet Sim 99", description: "Massive cute cat pet", price: 45.00, originalPrice: 65.00, stock: 10, category: "Pet", rarity: "Huge", imageUrl: "", isFeatured: true },
  { id: "12", name: "Titanic Dog", game: "Pet Sim 99", description: "Enormous dog pet", price: 55.00, originalPrice: 75.00, stock: 8, category: "Pet", rarity: "Titanic", imageUrl: "", isFeatured: true },
];

const Shop = () => {
  const [search, setSearch] = useState("");
  const [selectedGame, setSelectedGame] = useState("all");
  const [sortBy, setSortBy] = useState("featured");
  const [cartCount, setCartCount] = useState(0);

  let filteredItems = sampleItems.filter(item =>
    item.name.toLowerCase().includes(search.toLowerCase()) ||
    item.description.toLowerCase().includes(search.toLowerCase())
  );

  if (selectedGame !== "all") {
    filteredItems = filteredItems.filter(item =>
      item.game.toLowerCase().replace(/\s+/g, '') === selectedGame.toLowerCase()
    );
  }

  if (sortBy === "featured") {
    filteredItems = filteredItems.sort((a, b) => Number(b.isFeatured) - Number(a.isFeatured));
  } else if (sortBy === "price-low") {
    filteredItems = filteredItems.sort((a, b) => a.price - b.price);
  } else if (sortBy === "price-high") {
    filteredItems = filteredItems.sort((a, b) => b.price - a.price);
  }

  const getRarityColor = (rarity: string) => {
    switch (rarity.toLowerCase()) {
      case "chroma": return "border-primary/50 bg-primary/5";
      case "mythical": return "border-destructive/50 bg-destructive/5";
      case "legendary": return "border-amber-500/50 bg-amber-500/5";
      case "huge": return "border-accent/50 bg-accent/5";
      case "titanic": return "border-purple-500/50 bg-purple-500/5";
      case "godly": return "border-primary/50 bg-primary/5";
      default: return "border-border bg-card";
    }
  };

  const handleAddToCart = (item: ShopItem) => {
    setCartCount(cartCount + 1);
    toast({
      title: "Added to Cart",
      description: `${item.name} has been added to your cart.`,
    });
  };

  const discount = (item: ShopItem) => {
    if (!item.originalPrice) return 0;
    return Math.round(((item.originalPrice - item.price) / item.originalPrice) * 100);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="container mx-auto px-4 py-8">
        {/* Hero Banner */}
        <div className="relative mb-12 p-8 md:p-12 rounded-2xl bg-gradient-to-r from-primary/20 via-accent/20 to-primary/20 border border-primary/30 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-accent/10 animate-pulse" />
          <div className="relative z-10 text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/20 border border-primary/30 mb-4">
              <Zap className="h-4 w-4 text-primary" />
              <span className="text-sm font-semibold text-primary">Instant Delivery</span>
            </div>
            <h1 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
              Get Your Dream Items Within 5 Minutes
            </h1>
            <p className="text-lg text-muted-foreground mb-6">
              Secure instant delivery through our automated bot. No passwords needed, just your username!
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-card/50">
                <Shield className="h-5 w-5 text-accent" />
                <span className="text-sm">100% Safe</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-card/50">
                <Clock className="h-5 w-5 text-primary" />
                <span className="text-sm">2 Min Delivery</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-card/50">
                <Star className="h-5 w-5 text-amber-500 fill-amber-500" />
                <span className="text-sm">4.3/5 Rating</span>
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-8">
          <div className="relative flex-1 w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search items..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 bg-card border-border"
            />
          </div>
          <div className="flex gap-3 w-full md:w-auto">
            <Select value={selectedGame} onValueChange={setSelectedGame}>
              <SelectTrigger className="w-full md:w-48 bg-card border-border">
                <SelectValue placeholder="All Games" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Games</SelectItem>
                <SelectItem value="mm2">Murder Mystery 2</SelectItem>
                <SelectItem value="bladeball">Blade Ball</SelectItem>
                <SelectItem value="bloxfruits">Blox Fruits</SelectItem>
                <SelectItem value="growagarden">Grow a Garden</SelectItem>
                <SelectItem value="petsim99">Pet Simulator 99</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full md:w-48 bg-card border-border">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="featured">Featured</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="icon" className="relative">
              <ShoppingCart className="h-4 w-4" />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 h-5 w-5 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center font-bold">
                  {cartCount}
                </span>
              )}
            </Button>
          </div>
        </div>

        {/* Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className={`group relative rounded-xl border-2 p-4 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl ${getRarityColor(item.rarity)}`}
            >
              {item.isFeatured && (
                <div className="absolute top-2 right-2 px-2 py-1 rounded-full bg-primary/90 text-xs font-bold text-primary-foreground">
                  FEATURED
                </div>
              )}
              {discount(item) > 0 && (
                <div className="absolute top-2 left-2 px-2 py-1 rounded-full bg-destructive/90 text-xs font-bold text-destructive-foreground">
                  -{discount(item)}%
                </div>
              )}

              <div className="aspect-square rounded-lg bg-secondary/50 mb-4 flex items-center justify-center">
                <span className="text-4xl">🎮</span>
              </div>

              <div className="mb-3">
                <div className="flex items-center gap-2 mb-1">
                  <span className="px-2 py-0.5 rounded text-xs font-medium bg-secondary text-muted-foreground">
                    {item.game}
                  </span>
                  <span className="px-2 py-0.5 rounded text-xs font-medium bg-primary/20 text-primary">
                    {item.rarity}
                  </span>
                </div>
                <h3 className="font-display text-lg font-bold text-foreground">{item.name}</h3>
                <p className="text-sm text-muted-foreground mt-1">{item.description}</p>
              </div>

              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-display text-2xl font-bold text-primary">${item.price.toFixed(2)}</span>
                    {item.originalPrice && (
                      <span className="text-sm text-muted-foreground line-through">${item.originalPrice.toFixed(2)}</span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{item.stock} in stock</p>
                </div>
              </div>

              <Button
                variant="gold"
                className="w-full"
                onClick={() => handleAddToCart(item)}
                disabled={item.stock === 0}
              >
                <ShoppingCart className="h-4 w-4" />
                {item.stock > 0 ? 'Add to Cart' : 'Out of Stock'}
              </Button>
            </div>
          ))}
        </div>

        {filteredItems.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No items found matching your search.</p>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
};

export default Shop;
