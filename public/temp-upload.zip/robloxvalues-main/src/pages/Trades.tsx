import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Plus, MessageSquare, Clock, User, Shield, CheckCircle } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";

interface Trade {
  id: string;
  user: string;
  game: string;
  offering: string[];
  looking: string[];
  timestamp: string;
  needsMiddleman: boolean;
  hasMiddleman: boolean;
}

const sampleTrades: Trade[] = [
  {
    id: "1",
    user: "TradeMaster99",
    game: "MM2",
    offering: ["Chroma Luger", "Icebreaker"],
    looking: ["Chroma Fang"],
    timestamp: "5 min ago",
    needsMiddleman: true,
    hasMiddleman: false,
  },
  {
    id: "2",
    user: "FruitCollector",
    game: "Blox Fruits",
    offering: ["Dragon Fruit", "500M Beli"],
    looking: ["Leopard Fruit"],
    timestamp: "12 min ago",
    needsMiddleman: false,
    hasMiddleman: false,
  },
  {
    id: "3",
    user: "BladePro",
    game: "Blade Ball",
    offering: ["Inferno Blade"],
    looking: ["Plasma Saber", "Any Mythic"],
    timestamp: "25 min ago",
    needsMiddleman: true,
    hasMiddleman: true,
  },
  {
    id: "4",
    user: "GardenGuru",
    game: "Grow a Garden",
    offering: ["Rainbow Flower x3"],
    looking: ["Godly Seed x2"],
    timestamp: "1 hour ago",
    needsMiddleman: false,
    hasMiddleman: false,
  },
  {
    id: "5",
    user: "PetLover123",
    game: "Pet Sim 99",
    offering: ["Huge Cat", "Titanic Dog"],
    looking: ["Any Huge Exclusive"],
    timestamp: "2 hours ago",
    needsMiddleman: true,
    hasMiddleman: false,
  },
];

const Trades = () => {
  const [selectedGame, setSelectedGame] = useState<string>("all");
  const [filterMiddleman, setFilterMiddleman] = useState<string>("all");

  let filteredTrades = sampleTrades;
  
  if (selectedGame !== "all") {
    filteredTrades = filteredTrades.filter(trade => trade.game.toLowerCase().includes(selectedGame));
  }
  
  if (filterMiddleman === "needs") {
    filteredTrades = filteredTrades.filter(trade => trade.needsMiddleman && !trade.hasMiddleman);
  } else if (filterMiddleman === "has") {
    filteredTrades = filteredTrades.filter(trade => trade.hasMiddleman);
  }

  const handleMiddlemanRequest = (tradeId: string) => {
    toast({
      title: "Middleman Request Sent",
      description: "A trusted middleman will be assigned to this trade soon.",
    });
  };

  const handleVolunteerMiddleman = (tradeId: string) => {
    toast({
      title: "Volunteer as Middleman",
      description: "You need to be logged in and verified to become a middleman.",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
          <div>
            <h1 className="font-display text-4xl font-bold text-foreground mb-2">Trade Ads</h1>
            <p className="text-muted-foreground">Find trades or post your own - request middlemen for safety</p>
          </div>
          <Button variant="gold">
            <Plus className="h-4 w-4" />
            Post Trade
          </Button>
        </div>

        {/* Middleman Info Banner */}
        <div className="mb-6 p-4 rounded-lg bg-accent/10 border border-accent/30">
          <div className="flex items-start gap-3">
            <Shield className="h-6 w-6 text-accent mt-0.5" />
            <div>
              <h3 className="font-semibold text-foreground">Safe Trading with Middlemen</h3>
              <p className="text-sm text-muted-foreground">
                Request a trusted middleman for high-value trades. Our verified middlemen ensure both parties complete the trade safely.
              </p>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4 mb-6">
          <Select value={selectedGame} onValueChange={setSelectedGame}>
            <SelectTrigger className="w-48 bg-card border-border">
              <SelectValue placeholder="Filter by game" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Games</SelectItem>
              <SelectItem value="mm2">Murder Mystery 2</SelectItem>
              <SelectItem value="blade">Blade Ball</SelectItem>
              <SelectItem value="blox">Blox Fruits</SelectItem>
              <SelectItem value="garden">Grow a Garden</SelectItem>
              <SelectItem value="pet">Pet Simulator 99</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={filterMiddleman} onValueChange={setFilterMiddleman}>
            <SelectTrigger className="w-48 bg-card border-border">
              <SelectValue placeholder="Middleman filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Trades</SelectItem>
              <SelectItem value="needs">Needs Middleman</SelectItem>
              <SelectItem value="has">Has Middleman</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Trade List */}
        <div className="space-y-4">
          {filteredTrades.map((trade) => (
            <div
              key={trade.id}
              className={`p-6 rounded-lg bg-card border transition-colors ${
                trade.needsMiddleman && !trade.hasMiddleman 
                  ? 'border-amber-500/50 hover:border-amber-500' 
                  : trade.hasMiddleman 
                    ? 'border-accent/50 hover:border-accent'
                    : 'border-border hover:border-primary/30'
              }`}
            >
              <div className="flex flex-col gap-4">
                {/* Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center">
                      <User className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <span className="font-semibold text-foreground">{trade.user}</span>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <span className="px-2 py-0.5 rounded bg-secondary text-xs">{trade.game}</span>
                        <Clock className="h-3 w-3" />
                        <span>{trade.timestamp}</span>
                      </div>
                    </div>
                  </div>
                  
                  {/* Middleman Status */}
                  {trade.hasMiddleman && (
                    <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-accent/20 border border-accent/30">
                      <CheckCircle className="h-4 w-4 text-accent" />
                      <span className="text-sm font-medium text-accent">Middleman Assigned</span>
                    </div>
                  )}
                  {trade.needsMiddleman && !trade.hasMiddleman && (
                    <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-500/20 border border-amber-500/30">
                      <Shield className="h-4 w-4 text-amber-500" />
                      <span className="text-sm font-medium text-amber-500">Needs Middleman</span>
                    </div>
                  )}
                </div>

                {/* Trade Items */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <span className="text-sm text-accent font-medium">Offering:</span>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {trade.offering.map((item, i) => (
                        <span
                          key={i}
                          className="px-3 py-1 rounded-full bg-accent/10 border border-accent/30 text-sm text-foreground"
                        >
                          {item}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <span className="text-sm text-primary font-medium">Looking for:</span>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {trade.looking.map((item, i) => (
                        <span
                          key={i}
                          className="px-3 py-1 rounded-full bg-primary/10 border border-primary/30 text-sm text-foreground"
                        >
                          {item}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-wrap gap-3 pt-2 border-t border-border">
                  <Button variant="outline" size="sm">
                    <MessageSquare className="h-4 w-4" />
                    Contact Trader
                  </Button>
                  
                  {trade.needsMiddleman && !trade.hasMiddleman && (
                    <Button 
                      variant="secondary" 
                      size="sm"
                      onClick={() => handleVolunteerMiddleman(trade.id)}
                    >
                      <Shield className="h-4 w-4" />
                      Volunteer as Middleman
                    </Button>
                  )}
                  
                  {!trade.needsMiddleman && (
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => handleMiddlemanRequest(trade.id)}
                    >
                      <Shield className="h-4 w-4" />
                      Request Middleman
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Trades;
