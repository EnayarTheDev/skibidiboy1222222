import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, DollarSign, Search, Shield, AlertTriangle, User, Clock, Star } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";

interface Listing {
  id: string;
  seller: string;
  sellerRating: number;
  sellerTrades: number;
  game: string;
  item: string;
  quantity: number;
  price: number;
  currency: string;
  timestamp: string;
  verified: boolean;
}

const sampleListings: Listing[] = [
  {
    id: "1",
    seller: "ProTrader2024",
    sellerRating: 4.9,
    sellerTrades: 156,
    game: "MM2",
    item: "Chroma Luger",
    quantity: 1,
    price: 15.99,
    currency: "USD",
    timestamp: "10 min ago",
    verified: true,
  },
  {
    id: "2",
    seller: "FruitKing",
    sellerRating: 4.7,
    sellerTrades: 89,
    game: "Blox Fruits",
    item: "Leopard Fruit",
    quantity: 1,
    price: 25.00,
    currency: "USD",
    timestamp: "25 min ago",
    verified: true,
  },
  {
    id: "3",
    seller: "BladeDealer",
    sellerRating: 4.5,
    sellerTrades: 42,
    game: "Blade Ball",
    item: "Inferno Blade",
    quantity: 2,
    price: 8.50,
    currency: "USD",
    timestamp: "1 hour ago",
    verified: false,
  },
  {
    id: "4",
    seller: "PetCollector",
    sellerRating: 5.0,
    sellerTrades: 234,
    game: "Pet Sim 99",
    item: "Huge Cat",
    quantity: 1,
    price: 45.00,
    currency: "USD",
    timestamp: "2 hours ago",
    verified: true,
  },
  {
    id: "5",
    seller: "GardenMaster",
    sellerRating: 4.3,
    sellerTrades: 28,
    game: "Grow a Garden",
    item: "Godly Seed",
    quantity: 5,
    price: 12.00,
    currency: "USD",
    timestamp: "3 hours ago",
    verified: false,
  },
];

const BlackMarket = () => {
  const [search, setSearch] = useState("");
  const [selectedGame, setSelectedGame] = useState("all");
  const [sortBy, setSortBy] = useState("recent");

  let filteredListings = sampleListings.filter(listing =>
    listing.item.toLowerCase().includes(search.toLowerCase()) ||
    listing.seller.toLowerCase().includes(search.toLowerCase())
  );

  if (selectedGame !== "all") {
    filteredListings = filteredListings.filter(listing =>
      listing.game.toLowerCase().includes(selectedGame)
    );
  }

  if (sortBy === "price-low") {
    filteredListings = filteredListings.sort((a, b) => a.price - b.price);
  } else if (sortBy === "price-high") {
    filteredListings = filteredListings.sort((a, b) => b.price - a.price);
  } else if (sortBy === "rating") {
    filteredListings = filteredListings.sort((a, b) => b.sellerRating - a.sellerRating);
  }

  const handleBuy = (listing: Listing) => {
    toast({
      title: "Purchase Initiated",
      description: `Contact ${listing.seller} to complete the purchase. Use a middleman for safety!`,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <DollarSign className="h-10 w-10 text-destructive" />
              <h1 className="font-display text-4xl font-bold text-foreground">Black Market</h1>
            </div>
            <p className="text-muted-foreground">Buy and sell in-game items for real money</p>
          </div>
          <Button variant="gold">
            <Plus className="h-4 w-4" />
            Create Listing
          </Button>
        </div>

        {/* Warning Banner */}
        <div className="mb-6 p-4 rounded-lg bg-destructive/10 border border-destructive/30">
          <div className="flex items-start gap-3">
            <AlertTriangle className="h-6 w-6 text-destructive mt-0.5" />
            <div>
              <h3 className="font-semibold text-foreground">Trade at Your Own Risk</h3>
              <p className="text-sm text-muted-foreground">
                Real money trades are against most games' ToS. Always use a trusted middleman and verify seller ratings before purchasing. We are not responsible for any lost items or money.
              </p>
            </div>
          </div>
        </div>

        {/* Middleman Recommendation */}
        <div className="mb-6 p-4 rounded-lg bg-accent/10 border border-accent/30">
          <div className="flex items-start gap-3">
            <Shield className="h-6 w-6 text-accent mt-0.5" />
            <div>
              <h3 className="font-semibold text-foreground">Use a Middleman</h3>
              <p className="text-sm text-muted-foreground">
                For all Black Market transactions, we strongly recommend using a verified middleman. This protects both buyer and seller from scams.
              </p>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search items or sellers..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 bg-card border-border"
            />
          </div>
          <Select value={selectedGame} onValueChange={setSelectedGame}>
            <SelectTrigger className="w-48 bg-card border-border">
              <SelectValue placeholder="Filter by game" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Games</SelectItem>
              <SelectItem value="mm2">Murder Mystery 2</SelectItem>
              <SelectItem value="blade">Blade Ball</SelectItem>
              <SelectItem value="blox">Blox Fruits</SelectItem>
              <SelectItem value="garden">Grow a Garden</SelectItem>
              <SelectItem value="pet">Pet Simulator 99</SelectItem>
            </SelectContent>
          </Select>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-48 bg-card border-border">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="recent">Most Recent</SelectItem>
              <SelectItem value="price-low">Price: Low to High</SelectItem>
              <SelectItem value="price-high">Price: High to Low</SelectItem>
              <SelectItem value="rating">Seller Rating</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Listings Grid */}
        <div className="grid gap-4">
          {filteredListings.map((listing) => (
            <div
              key={listing.id}
              className={`p-6 rounded-lg bg-card border transition-colors ${
                listing.verified 
                  ? 'border-accent/30 hover:border-accent/50' 
                  : 'border-border hover:border-primary/30'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex-1">
                  {/* Seller Info */}
                  <div className="flex items-center gap-3 mb-3">
                    <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center">
                      <User className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-foreground">{listing.seller}</span>
                        {listing.verified && (
                          <span className="px-2 py-0.5 rounded bg-accent/20 text-xs text-accent font-medium">Verified</span>
                        )}
                      </div>
                      <div className="flex items-center gap-3 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Star className="h-3 w-3 text-primary fill-primary" />
                          <span>{listing.sellerRating}</span>
                        </div>
                        <span>•</span>
                        <span>{listing.sellerTrades} trades</span>
                      </div>
                    </div>
                  </div>

                  {/* Item Info */}
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-lg bg-primary/10 flex items-center justify-center">
                      <span className="text-2xl">🎮</span>
                    </div>
                    <div>
                      <h3 className="font-display text-xl font-bold text-foreground">
                        {listing.item} {listing.quantity > 1 && `x${listing.quantity}`}
                      </h3>
                      <div className="flex items-center gap-2 text-sm">
                        <span className="px-2 py-0.5 rounded bg-secondary text-muted-foreground">{listing.game}</span>
                        <Clock className="h-3 w-3 text-muted-foreground" />
                        <span className="text-muted-foreground">{listing.timestamp}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Price & Action */}
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="font-display text-3xl font-bold text-accent">
                      ${listing.price.toFixed(2)}
                    </p>
                    <p className="text-sm text-muted-foreground">{listing.currency}</p>
                  </div>
                  <Button 
                    variant="gold" 
                    onClick={() => handleBuy(listing)}
                  >
                    <DollarSign className="h-4 w-4" />
                    Buy Now
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredListings.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No listings found</p>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
};

export default BlackMarket;
