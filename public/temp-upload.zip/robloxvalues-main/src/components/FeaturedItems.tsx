import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ShoppingBag, Star, ArrowRight } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface FeaturedItem {
  id: string;
  name: string;
  game: string;
  price: number;
  originalPrice?: number;
  rarity: string;
  isFeatured: boolean;
}

const featuredItems: FeaturedItem[] = [
  { id: "1", name: "Chroma Luger", game: "MM2", price: 15.99, originalPrice: 19.99, rarity: "Chroma", isFeatured: true },
  { id: "2", name: "Chroma Fang", game: "MM2", price: 22.99, originalPrice: 29.99, rarity: "Chroma", isFeatured: true },
  { id: "4", name: "Dragon Fruit", game: "Blox Fruits", price: 25.00, originalPrice: 35.00, rarity: "Mythical", isFeatured: true },
  { id: "5", name: "Leopard Fruit", game: "Blox Fruits", price: 32.99, originalPrice: 45.00, rarity: "Mythical", isFeatured: true },
  { id: "7", name: "Inferno Blade", game: "Blade Ball", price: 12.99, originalPrice: 18.99, rarity: "Legendary", isFeatured: true },
  { id: "10", name: "Rainbow Flower", game: "Grow a Garden", price: 11.99, originalPrice: 16.99, rarity: "Rare", isFeatured: true },
];

export const FeaturedItems = () => {
  const handleQuickAdd = (item: FeaturedItem) => {
    toast({
      title: "Added to Cart",
      description: `${item.name} has been added to your cart.`,
    });
  };

  const discount = (item: FeaturedItem) => {
    if (!item.originalPrice) return 0;
    return Math.round(((item.originalPrice - item.price) / item.originalPrice) * 100);
  };

  return (
    <section className="py-16 bg-card/30">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Star className="h-6 w-6 text-primary fill-primary" />
              <h2 className="font-display text-3xl font-bold text-foreground">Featured Items</h2>
            </div>
            <p className="text-muted-foreground">Hot deals on the most wanted items</p>
          </div>
          <Button variant="outline" asChild>
            <Link to="/shop">
              View All
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredItems.map((item) => (
            <div
              key={item.id}
              className="group relative rounded-xl border-2 border-primary/30 bg-gradient-to-br from-card to-card/50 p-6 transition-all duration-300 hover:-translate-y-2 hover:shadow-xl hover:shadow-primary/20"
            >
              {discount(item) > 0 && (
                <div className="absolute top-4 right-4 px-3 py-1 rounded-full bg-destructive text-xs font-bold text-destructive-foreground">
                  -{discount(item)}% OFF
                </div>
              )}

              <div className="aspect-square rounded-lg bg-gradient-to-br from-primary/20 to-accent/20 mb-4 flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/10 animate-pulse" />
                <span className="text-6xl relative z-10">🎮</span>
              </div>

              <div className="mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="px-2 py-1 rounded text-xs font-medium bg-secondary text-muted-foreground">
                    {item.game}
                  </span>
                  <span className="px-2 py-1 rounded text-xs font-medium bg-primary/20 text-primary">
                    {item.rarity}
                  </span>
                </div>
                <h3 className="font-display text-xl font-bold text-foreground mb-1">{item.name}</h3>
              </div>

              <div className="flex items-center justify-between mb-4">
                <div className="flex items-baseline gap-2">
                  <span className="font-display text-3xl font-bold text-primary">${item.price.toFixed(2)}</span>
                  {item.originalPrice && (
                    <span className="text-sm text-muted-foreground line-through">
                      ${item.originalPrice.toFixed(2)}
                    </span>
                  )}
                </div>
              </div>

              <Button
                variant="gold"
                className="w-full"
                onClick={() => handleQuickAdd(item)}
              >
                <ShoppingBag className="h-4 w-4" />
                Add to Cart
              </Button>
            </div>
          ))}
        </div>

        <div className="text-center mt-10">
          <Button variant="gold" size="lg" asChild>
            <Link to="/shop">
              <ShoppingBag className="h-5 w-5" />
              Browse All Items
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};
