import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Calculator, Sparkles, Shield, DollarSign, ShoppingBag, Zap } from "lucide-react";

export const HeroSection = () => {
  return (
    <section className="relative overflow-hidden py-24 lg:py-36">
      {/* Animated background */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-card to-background" />
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[120px] animate-pulse" />
      <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-accent/10 rounded-full blur-[100px] animate-pulse" style={{ animationDelay: '1s' }} />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center max-w-5xl mx-auto">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary/20 to-accent/20 border border-primary/30 px-5 py-2.5 mb-8">
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="text-sm font-semibold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              #1 Trusted Trading Platform
            </span>
          </div>
          
          <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-bold mb-8 leading-tight">
            <span className="text-foreground">Your Ultimate</span>
            <br />
            <span className="bg-gradient-to-r from-primary via-amber-400 to-primary bg-clip-text text-transparent animate-shimmer bg-[length:200%_100%]">
              Roblox Values
            </span>
            <br />
            <span className="text-foreground">Hub</span>
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed">
            Instant item delivery, accurate values, safe trades with middleman support, and real money marketplace. MM2, Blade Ball, Blox Fruits & more.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-wrap justify-center gap-4 mb-16">
            <Button variant="gold" size="xl" asChild className="group">
              <Link to="/shop">
                <ShoppingBag className="h-5 w-5 group-hover:scale-110 transition-transform" />
                Shop Now
              </Link>
            </Button>
            <Button variant="outline" size="xl" asChild className="group">
              <Link to="/calculator">
                <Calculator className="h-5 w-5 group-hover:rotate-12 transition-transform" />
                Trade Calculator
              </Link>
            </Button>
            <Button variant="outline" size="xl" asChild>
              <Link to="/blackmarket">
                <DollarSign className="h-5 w-5" />
                Black Market
              </Link>
            </Button>
          </div>
          
          {/* Feature Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            <div className="group p-6 rounded-xl bg-gradient-to-b from-card to-card/50 border border-border hover:border-primary/50 transition-all duration-300 hover:-translate-y-1">
              <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4 mx-auto group-hover:bg-primary/20 transition-colors">
                <Zap className="h-7 w-7 text-primary" />
              </div>
              <h3 className="font-display text-xl font-bold text-foreground mb-2">Instant Shop</h3>
              <p className="text-muted-foreground text-sm">Buy items with instant delivery in 5 minutes</p>
            </div>

            <div className="group p-6 rounded-xl bg-gradient-to-b from-card to-card/50 border border-border hover:border-primary/50 transition-all duration-300 hover:-translate-y-1">
              <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4 mx-auto group-hover:bg-primary/20 transition-colors">
                <Calculator className="h-7 w-7 text-primary" />
              </div>
              <h3 className="font-display text-xl font-bold text-foreground mb-2">Fair Trades</h3>
              <p className="text-muted-foreground text-sm">Calculate exact values before every trade</p>
            </div>

            <div className="group p-6 rounded-xl bg-gradient-to-b from-card to-card/50 border border-border hover:border-accent/50 transition-all duration-300 hover:-translate-y-1">
              <div className="w-14 h-14 rounded-xl bg-accent/10 flex items-center justify-center mb-4 mx-auto group-hover:bg-accent/20 transition-colors">
                <Shield className="h-7 w-7 text-accent" />
              </div>
              <h3 className="font-display text-xl font-bold text-foreground mb-2">Safe Middleman</h3>
              <p className="text-muted-foreground text-sm">Request trusted middlemen for secure trades</p>
            </div>

            <div className="group p-6 rounded-xl bg-gradient-to-b from-card to-card/50 border border-border hover:border-destructive/50 transition-all duration-300 hover:-translate-y-1">
              <div className="w-14 h-14 rounded-xl bg-destructive/10 flex items-center justify-center mb-4 mx-auto group-hover:bg-destructive/20 transition-colors">
                <DollarSign className="h-7 w-7 text-destructive" />
              </div>
              <h3 className="font-display text-xl font-bold text-foreground mb-2">Black Market</h3>
              <p className="text-muted-foreground text-sm">Buy & sell items for real money</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
