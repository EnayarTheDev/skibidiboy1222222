/*
  # Shop System Schema

  ## Overview
  Creates tables for the integrated shop system allowing users to purchase Roblox items instantly.

  ## New Tables
  
  ### `shop_items`
  - `id` (uuid, primary key) - Unique identifier
  - `name` (text) - Item name
  - `game` (text) - Game the item belongs to (MM2, Blade Ball, etc)
  - `description` (text) - Item description
  - `price` (decimal) - Price in USD
  - `original_price` (decimal, optional) - Original price for showing discounts
  - `stock` (integer) - Available quantity
  - `category` (text) - Item category (Pet, Weapon, Fruit, etc)
  - `rarity` (text) - Item rarity (Common, Rare, Legendary, etc)
  - `image_url` (text, optional) - Image URL
  - `is_featured` (boolean) - Whether to show on homepage
  - `created_at` (timestamptz) - Creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### `orders`
  - `id` (uuid, primary key) - Unique identifier
  - `user_id` (uuid, optional) - Reference to auth.users (null for guest orders)
  - `roblox_username` (text) - Buyer's Roblox username
  - `email` (text) - Contact email
  - `total_amount` (decimal) - Total order amount
  - `status` (text) - Order status (pending, processing, completed, cancelled)
  - `delivery_status` (text) - Delivery status (pending, in_progress, delivered, failed)
  - `payment_method` (text) - Payment method used
  - `created_at` (timestamptz) - Order creation time
  - `completed_at` (timestamptz, optional) - Order completion time

  ### `order_items`
  - `id` (uuid, primary key) - Unique identifier
  - `order_id` (uuid) - Reference to orders table
  - `item_id` (uuid) - Reference to shop_items table
  - `quantity` (integer) - Number of items ordered
  - `price_at_purchase` (decimal) - Price at time of purchase
  - `created_at` (timestamptz) - Creation timestamp

  ### `cart_items`
  - `id` (uuid, primary key) - Unique identifier
  - `user_id` (uuid, optional) - Reference to auth.users (null for guest carts)
  - `session_id` (text, optional) - Session ID for guest users
  - `item_id` (uuid) - Reference to shop_items table
  - `quantity` (integer) - Number of items in cart
  - `created_at` (timestamptz) - Creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ## Security
  - Enable RLS on all tables
  - Shop items are publicly readable
  - Orders are only viewable by the order owner
  - Cart items are only accessible by the cart owner
*/

-- Create shop_items table
CREATE TABLE IF NOT EXISTS shop_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  game text NOT NULL,
  description text,
  price decimal(10,2) NOT NULL CHECK (price >= 0),
  original_price decimal(10,2) CHECK (original_price >= 0),
  stock integer NOT NULL DEFAULT 0 CHECK (stock >= 0),
  category text NOT NULL,
  rarity text NOT NULL,
  image_url text,
  is_featured boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  roblox_username text NOT NULL,
  email text NOT NULL,
  total_amount decimal(10,2) NOT NULL CHECK (total_amount >= 0),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'cancelled')),
  delivery_status text NOT NULL DEFAULT 'pending' CHECK (delivery_status IN ('pending', 'in_progress', 'delivered', 'failed')),
  payment_method text,
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

-- Create order_items table
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  item_id uuid NOT NULL REFERENCES shop_items(id) ON DELETE RESTRICT,
  quantity integer NOT NULL CHECK (quantity > 0),
  price_at_purchase decimal(10,2) NOT NULL CHECK (price_at_purchase >= 0),
  created_at timestamptz DEFAULT now()
);

-- Create cart_items table
CREATE TABLE IF NOT EXISTS cart_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  session_id text,
  item_id uuid NOT NULL REFERENCES shop_items(id) ON DELETE CASCADE,
  quantity integer NOT NULL DEFAULT 1 CHECK (quantity > 0),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT cart_user_or_session CHECK (user_id IS NOT NULL OR session_id IS NOT NULL)
);

-- Enable RLS
ALTER TABLE shop_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE cart_items ENABLE ROW LEVEL SECURITY;

-- Shop items policies (public read)
CREATE POLICY "Anyone can view shop items"
  ON shop_items FOR SELECT
  TO public
  USING (true);

-- Orders policies
CREATE POLICY "Users can view own orders"
  ON orders FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Anyone can create orders"
  ON orders FOR INSERT
  TO public
  WITH CHECK (true);

-- Order items policies
CREATE POLICY "Users can view own order items"
  ON order_items FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_items.order_id
      AND orders.user_id = auth.uid()
    )
  );

CREATE POLICY "Anyone can create order items"
  ON order_items FOR INSERT
  TO public
  WITH CHECK (true);

-- Cart items policies
CREATE POLICY "Users can view own cart items"
  ON cart_items FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own cart items"
  ON cart_items FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own cart items"
  ON cart_items FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own cart items"
  ON cart_items FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_shop_items_game ON shop_items(game);
CREATE INDEX IF NOT EXISTS idx_shop_items_category ON shop_items(category);
CREATE INDEX IF NOT EXISTS idx_shop_items_is_featured ON shop_items(is_featured);
CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_cart_items_user_id ON cart_items(user_id);
CREATE INDEX IF NOT EXISTS idx_cart_items_session_id ON cart_items(session_id);

-- Insert sample shop items
INSERT INTO shop_items (name, game, description, price, original_price, stock, category, rarity, is_featured) VALUES
  ('Chroma Luger', 'MM2', 'Legendary chroma weapon', 15.99, 19.99, 50, 'Weapon', 'Chroma', true),
  ('Chroma Fang', 'MM2', 'Rare chroma knife', 22.99, 29.99, 30, 'Weapon', 'Chroma', true),
  ('Icebreaker', 'MM2', 'Godly weapon', 8.99, 12.99, 100, 'Weapon', 'Godly', false),
  ('Dragon Fruit', 'Blox Fruits', 'Mythical fruit with dragon powers', 25.00, 35.00, 20, 'Fruit', 'Mythical', true),
  ('Leopard Fruit', 'Blox Fruits', 'Top tier mythical fruit', 32.99, 45.00, 15, 'Fruit', 'Mythical', true),
  ('Buddha Fruit', 'Blox Fruits', 'Legendary transformation fruit', 18.50, 25.00, 40, 'Fruit', 'Legendary', false),
  ('Inferno Blade', 'Blade Ball', 'Legendary fire blade', 12.99, 18.99, 75, 'Blade', 'Legendary', true),
  ('Plasma Saber', 'Blade Ball', 'Epic energy weapon', 9.99, 14.99, 60, 'Blade', 'Epic', false),
  ('Godly Seed', 'Grow a Garden', 'Rare godly plant seed', 4.99, 7.99, 200, 'Seed', 'Godly', false),
  ('Rainbow Flower', 'Grow a Garden', 'Beautiful rainbow flower', 11.99, 16.99, 80, 'Plant', 'Rare', true),
  ('Huge Cat', 'Pet Sim 99', 'Massive cute cat pet', 45.00, 65.00, 10, 'Pet', 'Huge', true),
  ('Titanic Dog', 'Pet Sim 99', 'Enormous dog pet', 55.00, 75.00, 8, 'Pet', 'Titanic', true)
ON CONFLICT DO NOTHING;
